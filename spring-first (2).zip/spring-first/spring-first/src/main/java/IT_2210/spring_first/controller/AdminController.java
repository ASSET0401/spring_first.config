package IT_2210.spring_first.controller;

import IT_2210.spring_first.model.AutoPart;
import IT_2210.spring_first.service.AutoPartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

    @Autowired
    private AutoPartService autoPartService;

    @GetMapping("/home") // Бұл логиннен кейін баратын бет
    public String home(Authentication authentication) {
        // 👇 Консольге авторизация рөлдерін шығарамыз
        System.out.println("ROLES: " + authentication.getAuthorities());

        // 👇 Егер қолданушыда ROLE_ADMIN рөлі болса — /admin бетіне бағыттаймыз
        if (authentication != null &&
                authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ADMIN"))) {
            System.out.println("REDIRECTING TO /admin"); // 👈 бұл тексеру үшін
            return "redirect:/admin";
        }

        // 👇 Әйтпесе, жай home.html көрсетіледі
        return "home";
    }



    @GetMapping("/admin")
    public String adminPage(Model model) {
        model.addAttribute("parts", autoPartService.getAllParts());
        model.addAttribute("part", new AutoPart());
        return "admin";
    }
}

