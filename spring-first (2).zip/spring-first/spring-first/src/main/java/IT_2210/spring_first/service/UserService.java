package IT_2210.spring_first.service;

import IT_2210.spring_first.model.AppUser;
import java.util.List;

public interface UserService {
    void save(AppUser user);
    AppUser findByUsername(String username);
}