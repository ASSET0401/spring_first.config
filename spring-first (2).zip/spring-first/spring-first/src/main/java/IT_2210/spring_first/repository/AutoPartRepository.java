package IT_2210.spring_first.repository;

import IT_2210.spring_first.model.AutoPart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutoPartRepository extends JpaRepository<AutoPart, Long> {
}