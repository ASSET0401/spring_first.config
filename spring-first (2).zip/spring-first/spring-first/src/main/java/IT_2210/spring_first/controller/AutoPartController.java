package IT_2210.spring_first.controller;

import IT_2210.spring_first.model.AutoPart;
import IT_2210.spring_first.service.AutoPartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class AutoPartController {

    @Autowired
    private AutoPartService autoPartService;





    @GetMapping("/shopAutoParts")
    public String shop(Model model) {
        model.addAttribute("autoParts", autoPartService.getAllParts());
        return "shop";
    }

    // Create - add new part
    @PostMapping("/admin/add")
    public String add(@ModelAttribute AutoPart part) {
        autoPartService.save(part);
        return "redirect:/admin";
    }

    // Update - show edit form
    @GetMapping("/admin/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        AutoPart part = autoPartService.getPartById(id);
        model.addAttribute("part", part);
        return "edit";
    }

    // Update - process edited part
    @PostMapping("/admin/update/{id}")
    public String updatePart(@PathVariable Long id, @ModelAttribute AutoPart updatedPart) {
        autoPartService.update(id, updatedPart);
        return "redirect:/admin";
    }

    // Delete
    @GetMapping("/admin/delete/{id}")
    public String deletePart(@PathVariable Long id) {
        autoPartService.deleteById(id);
        return "redirect:/admin";
    }
}
