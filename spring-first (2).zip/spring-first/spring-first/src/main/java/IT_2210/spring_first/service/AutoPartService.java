package IT_2210.spring_first.service;

import IT_2210.spring_first.model.AutoPart;

import java.util.List;

public interface AutoPartService {
    void save(AutoPart part);
    List<AutoPart> getAllParts();
    AutoPart getPartById(Long id);
    void update(Long id, AutoPart updatedPart);
    void deleteById(Long id);
}
