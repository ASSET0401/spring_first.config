package IT_2210.spring_first.service;

import IT_2210.spring_first.model.AutoPart;
import IT_2210.spring_first.repository.AutoPartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AutoPartServiceImpl implements AutoPartService {

    @Autowired
    private AutoPartRepository repository;

    @Override
    public void save(AutoPart part) {
        repository.save(part);
    }

    @Override
    public List<AutoPart> getAllParts() {
        return repository.findAll();
    }

    @Override
    public AutoPart getPartById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public void update(Long id, AutoPart updatedPart) {
        AutoPart existing = getPartById(id);
        if (existing != null) {
            existing.setName(updatedPart.getName());
            existing.setType(updatedPart.getType());
            repository.save(existing);
        }
    }

    @Override
    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}
