// CustomUserDetailsService.java
package IT_2210.spring_first.service;

import IT_2210.spring_first.model.AppUser;
import IT_2210.spring_first.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        System.out.println("LOADING: " + username); // 🔍 лог 1
        AppUser user = userRepository.findByUsername(username);
        if (user == null) {
            System.out.println("User not found: " + username); // 🔍 лог 2
            throw new UsernameNotFoundException("User not found");
        }
        System.out.println("FOUND: " + user.getUsername());     // 🔍 лог 3
        System.out.println("ROLE: " + user.getRole());          // 🔍 лог 4
        System.out.println("PASSWORD: " + user.getPassword());  // 🔍 лог 5

        GrantedAuthority authority = new SimpleGrantedAuthority(user.getRole());
        return new User(user.getUsername(), user.getPassword(), Collections.singletonList(authority));
    }
}

