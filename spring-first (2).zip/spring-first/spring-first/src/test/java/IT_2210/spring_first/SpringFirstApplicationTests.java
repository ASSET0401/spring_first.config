package IT_2210.spring_first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
